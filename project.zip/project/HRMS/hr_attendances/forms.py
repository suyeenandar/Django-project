from django import forms
from django.forms import widgets
from .models import AttendanceModel

STATUS_CHOICES =(
    ('draft', 'draft'),
    ('Confirm', 'confirm'),
    ('Cancel', 'cancel')
)

class AttendanceForm(forms.ModelForm):
    
    class Meta:
        model = AttendanceModel
        fields = "__all__"
        labels  = {
            'name':'Enter Name', 
            'age':'Enter Your Age',  
            'birthday':'Enter Your Birthday',
            'address':'Address', 
            'email':'Email', 
            'ph_number':'Enter Your Ph_Number', 
            'gender':'Gender',
            'level':'Enter Your Level', 
            'present':'Present', 
            'absence':'Absence',  
            'image':'Upload Image'
        }
        widgets = {
            'name': widgets.TextInput(attrs={'placeholder':'Your Name','class': 'form-control'}),
            'age': widgets.NumberInput(attrs={'placeholder':'0','class': 'form-control'}),
            'birthday': widgets.DateInput(attrs={'placeholder':'Enter Birthday', 'type': 'date','class': 'form-control'}),
            'address': widgets.TextInput(attrs={'placeholder':'Enter Your Address','class': 'form-control'}),
            'email': widgets.TextInput(attrs={'placeholder':'Email','class': 'form-control'}),
            'ph_number': widgets.NumberInput({'placeholder':'Enter Your Ph Number','class': 'form-control'}),
            'gender': widgets.TextInput(attrs={'placeholder':'Gender','class': 'form-control'}),
            'level': widgets.TextInput(attrs={'placeholder':'Level','class': 'form-control'}),
            'present': widgets.Select(choices=STATUS_CHOICES,attrs={'class': 'form-control'}),
            'absence': widgets.Select(choices=STATUS_CHOICES,attrs={'class': 'form-control'}),
            'image': widgets.ClearableFileInput(attrs={'class': 'form-control'})
        }