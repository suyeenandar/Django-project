from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView
from django.urls import reverse_lazy
from hr_attendances import models
from hr_attendances import forms
from django.shortcuts import render, redirect
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q
from django.views import View
from .models import AttendanceModel

class SearchBy(View):

    def get(self, request):
        search = request.GET.get('search')
        if search:    
            attendances = AttendanceModel.objects.filter(
                Q(name__icontains=search) | 
                Q(age__icontains=search) |
                Q(birthday__icontains=search) |
                Q(address__icontains=search) |
                Q(email__icontains=search) |
                Q(ph_number__icontains=search) |
                Q(gender__icontains=search) |
                Q(level__icontains=search) 

            )
        else:
            attendances = AttendanceModel.objects.all()
        return render(request, 'attendance_list.html', {'all_attendances': attendances})

class OrderBy(View):

    def get(self, request):
        order = request.GET.get('order')
        attendances = AttendanceModel.objects.all().order_by("-"+ order)
        order_selected = {str(order): 'btn-primary text-white'}
        return render(request, 'attendance_list.html', {'all_attendances': attendances, 'order_selected': order_selected})

class AttendanceDetailView(PermissionRequiredMixin, DetailView):
    login_url = 'login'
    permission_required = 'hr_attendances.view_attendancemodel'
    model = models.AttendanceModel
    context_object_name = "attendance"
    template_name = 'attendance_detail.html'

class AttendanceListView(LoginRequiredMixin, ListView):
    paginate_by = 1
    login_url = 'login'
    model = models.AttendanceModel
    context_object_name = 'all_attendances'
    template_name = 'attendance_list.html'

class AttendanceCreateView(PermissionRequiredMixin, CreateView):
    login_url = 'login'
    permission_required = 'hr_attendances.add_attendancemodel'
    success_url = reverse_lazy("attendance_list")
    model = models.AttendanceModel
    form_class = forms.AttendanceForm
    template_name = 'attendance_create.html'

class AttendanceUpdateView(PermissionRequiredMixin, UpdateView):
    login_url = 'login'
    permission_required = 'hr_attendances.change_attendancemodel'
    success_url = reverse_lazy("attendance_list")
    model = models.AttendanceModel
    form_class = forms.AttendanceForm
    context_object_name = "attendance"
    template_name = 'attendance_update.html'

class AttendanceDeleteView(PermissionRequiredMixin, DeleteView):
    # success_url = reverse_lazy("attendance_list")
    # model = models.attendanceModel
    # context_object_name = "attendance"

    # def get(self, request, *args, **kwargs):
    #     return self.post(request, *args, **kwargs)

    login_url = 'login'
    permission_required = 'hr_attendances.delete_attendancemodel'

    def get(self, request, pk):
        attendance = models.AttendanceModel.objects.get(id=pk)  
        attendance.delete()
        return redirect('attendance_list')