from django.db import models

# Create your models here.
from django.utils import timezone
from hr_departments.models import DepartmentModel
from hr_tags.models import JobTagModel

class AttendanceModel(models.Model):
    
    class Meta:
        permissions = (
            ("view_attendancemodel", "Can view attendance model"),
        )
    name = models.CharField(max_length=20, verbose_name='Name')
    age = models.IntegerField(verbose_name='Age')
    birthday = models.DateField(verbose_name='Birthday', default=timezone.now)
    address = models.TextField(max_length=100, verbose_name='Address')  
    email = models.EmailField(max_length=50, default='test@gmail.com')
    ph_number = models.IntegerField(default='Ph Number')
    gender = models.CharField(max_length=10, verbose_name='Gender', default='other')
    level = models.CharField(max_length=20, default='Level')
    present = models.BooleanField(verbose_name='Present', default=False)
    image = models.ImageField(verbose_name='Image', default=None)
    department = models.ForeignKey(DepartmentModel, on_delete=models.CASCADE, default=None)
    tags = models.ManyToManyField(JobTagModel)

    def __str__(self):
        return self.name