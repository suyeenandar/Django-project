from django.db import models

# Create your models here.
from django.utils import timezone
from hr_jobs.models import JobModel
from hr_tags.models import EmployeeTagModel

class ExpenseModel(models.Model):
    
    class Meta:
        permissions = (
            ("view_expensemodel", "Can view expense model"),
        )

    date = models.DateField(verbose_name='Date', default=timezone.now)
    description = models.TextField(max_length=100, verbose_name='Description')
    meals = models.IntegerField(verbose_name='Meals')
    entertainment = models.IntegerField(verbose_name='Entertainment')
    trans = models.IntegerField(verbose_name='Air&Trans')
    lodging = models.IntegerField(verbose_name='Lodging')
    other = models.TextField(max_length=100, verbose_name='Other')
    total = models.IntegerField(verbose_name='Total')
    start_date = models.DateTimeField(verbose_name='Start Date', default=timezone.now)
    end_date = models.DateTimeField(verbose_name='End Date', default=timezone.now)
    image = models.ImageField(verbose_name='Image', default=None)
    job = models.ForeignKey(JobModel, on_delete=models.CASCADE, default=None)
    tags = models.ManyToManyField(EmployeeTagModel)


    
    # is_married = models.BooleanField(verbose_name='Is Married', default=False)  
    # joining_date = models.DateTimeField(verbose_name='Joining Date', default=timezone.now)
    # image = models.ImageField(verbose_name='Image', default=None)



    def __str__(self):
        return self.name