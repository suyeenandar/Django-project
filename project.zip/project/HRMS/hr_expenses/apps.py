from django.apps import AppConfig


class HrExpensesConfig(AppConfig):
    name = 'hr_expenses'
