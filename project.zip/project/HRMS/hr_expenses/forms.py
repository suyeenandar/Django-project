from django import forms
from django.forms import widgets
from .models import ExpenseModel

STATUS_CHOICES =(
    ('draft', 'draft'),
    ('Confirm', 'confirm'),
    ('Cancel', 'cancel')
)

class ExpenseForm(forms.ModelForm):
    
    class Meta:
        model = ExpenseModel
        fields = "__all__"
        labels  = {
            'date':'Enter Date', 
            'description':'Enter Description',  
            'meals':'Meals',
            'entertainment':'Entertainment', 
            'trans':'Trans', 
            'lodging':'Lodging', 
            'other':'Other', 
            'total':'Enter Total',
            'start_date':'Enter Start_Date',
            'end_date':'Enter End_Date',
            'image':'Upload Image'

        }
        widgets = {
            'date': widgets.DateInput(attrs={'placeholder':'Date', 'type': 'date','class': 'form-control'}),
            'description': widgets.TextInput(attrs={'placeholder':'description','class': 'form-control'}),
            'meals': widgets.NumberInput(attrs={'placeholder':'0','class': 'form-control'}),
            'entertainment': widgets.NumberInput(attrs={'placeholder':'0','class': 'form-control'}),
            'trans': widgets.NumberInput(attrs={'placeholder':'0','class': 'form-control'}),
            'lodging': widgets.NumberInput(attrs={'placeholder':'0','class': 'form-control'}),
            'other': widgets.NumberInput(attrs={'placeholder':'0','class': 'form-control'}),
            'total': widgets.NumberInput(attrs={'placeholder':'0','class': 'form-control'}),
            'start_date': widgets.DateInput(attrs={'placeholder':'Enter Start Date', 'type': 'date','class': 'form-control'}),
            'end_date': widgets.DateInput(attrs={'placeholder':'Enter End Date', 'type': 'date','class': 'form-control'}),
            'image': widgets.ClearableFileInput(attrs={'class': 'form-control'})
        }