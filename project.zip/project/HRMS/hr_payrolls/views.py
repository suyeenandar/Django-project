from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView
from django.urls import reverse_lazy
from hr_payrolls import models
from hr_payrolls import forms
from django.shortcuts import render, redirect
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q
from django.views import View
from .models import PayrollModel

class SearchBy(View):

    def get(self, request):
        search = request.GET.get('search')
        if search:    
            payrolls = PayrollModel.objects.filter(
                Q(name__icontains=search) | 
                Q(age__icontains=search) |
                Q(birthday__icontains=search) |
                Q(address__icontains=search) |
                Q(email__icontains=search) |
                Q(ph_number__icontains=search) |
                Q(gender__icontains=search) |
                Q(level__icontains=search) 

            )
        else:
            payrolls = PayrollModel.objects.all()
        return render(request, 'payroll_list.html', {'all_payrolls': payrolls})

class OrderBy(View):

    def get(self, request):
        order = request.GET.get('order')
        payrolls = PayrollModel.objects.all().order_by("-"+ order)
        order_selected = {str(order): 'btn-primary text-white'}
        return render(request, 'payroll_list.html', {'all_payrolls': payrolls, 'order_selected': order_selected})

class PayrollDetailView(PermissionRequiredMixin, DetailView):
    login_url = 'login'
    permission_required = 'hr_payrolls.view_payrollmodel'
    model = models.PayrollModel
    context_object_name = "payroll"
    template_name = 'payroll_detail.html'

class PayrollListView(LoginRequiredMixin, ListView):
    paginate_by = 1
    login_url = 'login'
    model = models.PayrollModel
    context_object_name = 'all_payrolls'
    template_name = 'payroll_list.html'

class PayrollCreateView(PermissionRequiredMixin, CreateView):
    login_url = 'login'
    permission_required = 'hr_payrolls.add_payrollmodel'
    success_url = reverse_lazy("payroll_list")
    model = models.PayrollModel
    form_class = forms.PayrollForm
    template_name = 'payroll_create.html'

class PayrollUpdateView(PermissionRequiredMixin, UpdateView):
    login_url = 'login'
    permission_required = 'hr_payrolls.change_payrollmodel'
    success_url = reverse_lazy("payroll_list")
    model = models.PayrollModel
    form_class = forms.PayrollForm
    context_object_name = "payroll"
    template_name = 'payroll_update.html'

class PayrollDeleteView(PermissionRequiredMixin, DeleteView):
    # success_url = reverse_lazy("payroll_list")
    # model = models.payrollModel
    # context_object_name = "payroll"

    # def get(self, request, *args, **kwargs):
    #     return self.post(request, *args, **kwargs)

    login_url = 'login'
    permission_required = 'hr_payrolls.delete_payrollmodel'

    def get(self, request, pk):
        payroll = models.payrollModel.objects.get(id=pk)  
        payroll.delete()
        return redirect('payroll_list')