from django.db import models

# Create your models here.
from django.utils import timezone
from hr_departments.models import DepartmentModel
from hr_tags.models import JobTagModel

class PayrollModel(models.Model):
    
    class Meta:
        permissions = (
            ("view_payrollmodel", "Can view payroll model"),
        )
    name = models.CharField(max_length=20, verbose_name='Name')
    age = models.IntegerField(verbose_name='Age')
    birthday = models.DateField(verbose_name='Birthday', default=timezone.now)
    address = models.TextField(max_length=100, verbose_name='Address')  
    email = models.EmailField(max_length=50, default='test@gmail.com')
    ph_number = models.IntegerField(verbose_name='Ph Number')
    gender = models.CharField(max_length=10, verbose_name='Gender', default='other')
    level = models.CharField(max_length=20, default='Level')
    position = models.CharField(max_length=50,default='Position')
    basic_salary = models.IntegerField(verbose_name='Basic Salary')
    day_of_attendance = models.IntegerField(verbose_name='Day of Attendance')
    leave = models.IntegerField(verbose_name='Leave')
    sub_total = models.IntegerField(verbose_name='Sub Total')
    actual_amount = models.IntegerField(verbose_name='Actual Amount')
    department = models.ForeignKey(DepartmentModel,on_delete=models.CASCADE,default=None)
    tags = models.ManyToManyField(JobTagModel)
    

    def __str__(self):
        return self.name