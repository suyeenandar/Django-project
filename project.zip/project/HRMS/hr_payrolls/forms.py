from django import forms
from django.forms import widgets
from .models import PayrollModel

STATUS_CHOICES =(
    ('draft', 'draft'),
    ('Confirm', 'confirm'),
    ('Cancel', 'cancel')
)

class PayrollForm(forms.ModelForm):
    
    class Meta:
        model = PayrollModel
        fields = "__all__"
        labels  = {
            'name':'Enter Name', 
            'age':'Enter Your Age',  
            'birthday':'Enter Your Birthday',
            'address':'Address', 
            'email':'Email', 
            'ph_number':'Enter Your Ph_Number', 
            'gender':'Gender',
            'level':'Enter Your Level',
            'position':'Enter Your Position', 
            'basic_salary':'Enter Your Basic Salary', 
            'day_of_attendance':'Days of Attendance', 
            'leave':'leave', 
            'sub_total':'Sub Total', 
            'actual_amount':'Actual Amount', 
        }
        widgets = {
            'name': widgets.TextInput(attrs={'placeholder':'Your Name','class': 'form-control'}),
            'age': widgets.NumberInput(attrs={'placeholder':'0','class': 'form-control'}),
            'birthday': widgets.DateInput(attrs={'placeholder':'Enter Birthday', 'type': 'date','class': 'form-control'}),
            'address': widgets.TextInput(attrs={'placeholder':'Enter Your Address','class': 'form-control'}),
            'email': widgets.TextInput(attrs={'placeholder':'Email','class': 'form-control'}),
            'ph_number': widgets.NumberInput({'placeholder':'Enter Your Ph Number','class': 'form-control'}),
            'gender': widgets.TextInput(attrs={'placeholder':'Gender','class': 'form-control'}),
            'level': widgets.TextInput(attrs={'placeholder':'Level','class': 'form-control'}),
            'position': widgets.TextInput(attrs={'placeholder':'Position','class': 'form-control'}),
            'basic_salary': widgets.NumberInput(attrs={'placeholder':'Basic Salary','class': 'form-control'}),
            'day_of_attendance': widgets.NumberInput(attrs={'placeholder':'Day of Attendance','class': 'form-control'}),
            'leave': widgets.NumberInput(attrs={'placeholder':'Leave','class': 'form-control'}),
            'sub_total': widgets.NumberInput(attrs={'placeholder':'Sub Total','class': 'form-control'}),
            'actual_amount': widgets.NumberInput(attrs={'placeholder':'Actual Amount','class': 'form-control'}),
        }